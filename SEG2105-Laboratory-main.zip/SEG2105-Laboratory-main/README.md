# SEG2105-Laboratory
Software Engineering (2105) Laboratory section B02, Fall 2023 - uOttawa
